<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css"/>
</head>
<body>
<div class="container pt-2 pb-2">
    <div class="row">
        <div class="col-8">
            <form>
                <div class="form-group mb-3">
                    <label>Email address</label>
                    <input name="email" type="email" class="form-control" placeholder="Enter email"/>
                </div>
                <div class="form-group mb-3">
                    <label>Password</label>
                    <input name="password" type="password" class="form-control" placeholder="Password"/>
                </div>
                <button type="submit" class="btn btn-primary">Login</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>
