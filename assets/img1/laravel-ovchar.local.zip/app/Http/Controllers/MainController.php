<?php

namespace App\Http\Controllers;

use App\Models\Cinema;
use Illuminate\Http\Request;

class MainController extends Controller
{
    function index(Request $request){

        $cinemas = Cinema::paginate(5);

        return view('main', compact('cinemas'));
    }
}
